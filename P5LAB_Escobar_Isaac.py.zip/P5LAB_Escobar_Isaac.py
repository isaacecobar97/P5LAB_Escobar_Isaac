# Name: Isaac Escobar
# Date: 07/16/2026
# Assignment: P5LAB
# Description: This program simulates a self-checkout machine by generating
# a random amount owed, accepting the customer's payment, and displaying
# the change in dollars, quarters, dimes, nickels, and pennies.

# Pseudocode:
# Start program
#
# Import random module
#
# Create function disperse_change(change)
#
#     Convert change amount into cents
#
#     If change equals 0
#         Display "No change"
#
#     Else
#         Calculate number of dollars
#         Calculate number of quarters
#         Calculate number of dimes
#         Calculate number of nickels
#         Calculate number of pennies
#
#         Display each type of money when the amount is greater than 0
#
#     End If
#
# End function
#
# Create main function
#
#     Generate a random amount owed between $0.01 and $100.00
#
#     Display amount owed
#
#     Ask user for amount of cash entered
#
#     Calculate the change owed to the customer
#
#     Display the change amount
#
#     Call disperse_change(change)
#
# End main function
#
# Call main function
#
# End program


import random


def disperse_change(change):

    # Convert value to a whole number
    change = round(change * 100)

    # Check if there is no change
    if change == 0:
        print("No change")
    else:

        # Determine how many dollars and coins are needed
        num_dollars = change // 100
        change = change - (num_dollars * 100)

        num_quarters = change // 25
        change = change - (num_quarters * 25)

        num_dimes = change // 10
        change = change - (num_dimes * 10)

        num_nickels = change // 5
        change = change - (num_nickels * 5)

        num_pennies = change

        # Display dollars
        if num_dollars > 0:
            if num_dollars == 1:
                print(f"{num_dollars} Dollar")
            else:
                print(f"{num_dollars} Dollars")

        # Display quarters
        if num_quarters > 0:
            if num_quarters == 1:
                print(f"{num_quarters} Quarter")
            else:
                print(f"{num_quarters} Quarters")

        # Display dimes
        if num_dimes > 0:
            if num_dimes == 1:
                print(f"{num_dimes} Dime")
            else:
                print(f"{num_dimes} Dimes")

        # Display nickels
        if num_nickels > 0:
            if num_nickels == 1:
                print(f"{num_nickels} Nickel")
            else:
                print(f"{num_nickels} Nickels")

        # Display pennies
        if num_pennies > 0:
            if num_pennies == 1:
                print(f"{num_pennies} Penny")
            else:
                print(f"{num_pennies} Pennies")


def main():

    # Generate random amount owed
    amount_owed = round(random.uniform(0.01, 100.00), 2)

    print(f"You owe ${amount_owed:.2f}")

    # Get payment from customer
    cash = float(input("How much cash will you put in the self-checkout? "))

    # Calculate change
    change = round(cash - amount_owed, 2)

    print(f"Change is: ${change:.2f}")

    # Display the change
    disperse_change(change)


main()